  <table width="100%" border="0" summary=
  "divide in tre parti lo schermo per presentare la testata come ||IMG| Titolo 
|IMG||">
    <thead>
      <tr>
        <th><img src="images/sx.png" alt="IMAGE [EQN]"
        height="200" width="250"></th>

        <th valign="middle">
          <div align="center">
            <h1>METODO DEL SIMPLESSO</h1>

            <h2>Universit&agrave; Politecnica delle Marche</h2>

            <h3>Tesina di Gionata Massi per il corso di Ricerca Operativa</h3>

          </div>
        </th>

        <th><img src="images/dx.png" alt="IMAGE [MTX]" height="200"
        width="250"></th>
      </tr>
    </thead>
  </table>
